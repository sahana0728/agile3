package testexample

func GetString() string {
	return "Hello String"
}

func GetInt() int {
	return 768
}

func MakeSumm(a, b int) int {
	return a + b
}
