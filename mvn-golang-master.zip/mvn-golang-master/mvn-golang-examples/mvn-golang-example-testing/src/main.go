package main

import (
	"fmt"
	"mypackage/testexample"
)

func main() {
	fmt.Printf("%s %d\n", testexample.GetString(), testexample.GetInt())
}
