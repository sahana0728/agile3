package pack1

func Pack1() string {
    return "Pack1"
}