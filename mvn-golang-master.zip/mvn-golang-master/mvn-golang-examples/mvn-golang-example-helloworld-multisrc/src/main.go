package main

import (
	"fmt"
	"pack2"
)

func main() {
	fmt.Printf("Hello, " + pack2.Pack2() + "\n")
}
