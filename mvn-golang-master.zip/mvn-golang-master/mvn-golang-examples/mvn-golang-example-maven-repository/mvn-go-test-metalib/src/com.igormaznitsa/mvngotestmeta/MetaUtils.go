package mvngotestmeta

func SomeMetaMethod(arg string) string {
	return "Hello " + arg
}
