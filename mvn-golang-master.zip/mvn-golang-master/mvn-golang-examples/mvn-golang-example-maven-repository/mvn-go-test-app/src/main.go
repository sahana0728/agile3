package main

import (
	"com.igormaznitsa/mvngotest"
	"com.igormaznitsa/mvngotesttwo"
)

func main() {
	mvngotest.SomeTestMethod()
	mvngotesttwo.SomeTestMethodTwo()
}
